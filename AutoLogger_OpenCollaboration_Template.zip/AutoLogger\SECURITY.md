# Security Policy
| Version | Supported |
|----------|------------|
| main (latest) | ✅ |
| dev / experimental | ⚠️ Partial |
| old releases | ❌ No support |
Please report via email: **security@autologger.dev**
or open a private advisory on GitHub.
