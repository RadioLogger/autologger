# Disclaimer
This project is educational, non-commercial, and does not use radio frequencies for any financial transaction.
