# Contributing to AutoLogger
Fork the repo, branch your changes, and submit a Pull Request.
