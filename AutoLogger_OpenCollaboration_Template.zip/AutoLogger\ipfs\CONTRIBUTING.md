# Contributing to ipfs
Please follow project coding and PR guidelines.
