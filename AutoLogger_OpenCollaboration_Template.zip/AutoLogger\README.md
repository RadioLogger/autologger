# 🛰️ AutoLogger Ecosystem

![License](https://img.shields.io/badge/license-MIT-blue)
![Contributors](https://img.shields.io/github/contributors/tutwidi/AutoLogger)
![Stars](https://img.shields.io/github/stars/tutwidi/AutoLogger?style=social)
![Status](https://img.shields.io/badge/status-active-success)

AutoLogger is a decentralized, educational open collaboration project integrating IoT, IPFS, and blockchain.
